/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import static junit.framework.Assert.assertEquals;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author apand
 */
public class Unit1Test {
    
    public Unit1Test() {
        
    }

    @Test
    public void testSomeMethod() {
    }

    /**
     * Test of retur method, of class Unit1.
     */
    @Test
    public void  testRetur() {
         System.out.println("test");
        Unit1 instance = new Unit1("hari");
        String expResult = "arun";
        String result;
        result = instance.retur();
        assertEquals(expResult, result);
    }

    /**
     * Test of main method, of class Unit1.
     */
    @Test
    public void testMain() {
    }
    
}
