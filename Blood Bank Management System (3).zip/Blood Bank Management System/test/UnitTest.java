/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.fail;
import org.junit.Test;
import org.junit.*;
/*import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;*/

/**
 *
 * @author apand
 */
public class UnitTest {
    
    public UnitTest() {
    }
    
    /**
     * Test of test method, of class Unit.
     */
    @Test
    public void testCheck() {
    }

    /**
     * Test of retur method, of class Unit.
     */
    @Test
    public void testRetur() {
        System.out.println("test");
        Unit instance = new Unit("O+");
        int expResult = 27;
        int  result = instance.retur();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
     
    }

    /**
     * Test of main method, of class Unit.
     */
    @Test
    public void testMain() {
    }
    
}
