
import Project.ConnectionProvider;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author apand
 */
public class Unit1 {
    String id;

    /**
     *
     * @return
     */
    public Unit1(String c)       
    {
        String bl=c;
        try {
 
            // SQL command data stored in String datatype
            String sql = "select name from donor where name like '%"+bl+"%'";
            Connection con=ConnectionProvider.getCon();
            Statement st=con.createStatement();
             ResultSet rs=st.executeQuery(sql);
 
            // Condition check
            while (rs.next()) {
 
                id = rs.getString("name");
            }
        }
        // Catch block to handle exception
        catch (Exception e) {
 
            // Print exception pop-up on screen
            System.out.println(e);
         
        }
    }
    public String retur()
    {
        return id;
    }

public static void main(String[] args) {
 //   Unit myObj = new Unit("O+"); // Create an object of class Main (This will call the constructor)
//    int a=myObj.retur();
//    System.out.println(a);
}
}